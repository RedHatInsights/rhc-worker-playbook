default_process_isolation_executable = 'podman'
default_container_image = 'quay.io/ansible/ansible-runner:devel'
registry_auth_prefix = 'ansible_runner_registry_'

# for ansible-runner worker cleanup command
GRACE_PERIOD_DEFAULT = 60  # minutes
